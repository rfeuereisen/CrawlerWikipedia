import requests

def get_related_articles(url, num_articles):
    base_url = "https://en.wikipedia.org/w/api.php"

    # Extract the page title from the URL
    page_title = url.split("/")[-1]

    # Make a request to the Wikipedia API to fetch the related articles
    params = {
        "action": "query",
        "format": "json",
        "prop": "extracts",
        "exintro": True,
        "explaintext": True,
        "generator": "search",
        "gsrsearch": f"morelike:{page_title}",
        "gsrnamespace": 0,
        "gsrlimit": num_articles
    }

    response = requests.get(base_url, params=params)
    data = response.json()

    articles = []
    if "query" in data and "pages" in data["query"]:
        pages = data["query"]["pages"]
        for page_id, page_data in pages.items():
            article_title = page_data["title"]
            article_intro = page_data["extract"]
            article_link = f"https://en.wikipedia.org/?curid={page_id}"
            articles.append({"title": article_title, "link": article_link, "introduction": article_intro})

    return articles

def main():
    url = input("Enter the URL of the Wikipedia article: ")
    num_articles = int(input("Enter the number of related articles to retrieve: "))

    related_articles = get_related_articles(url, num_articles)

    print("\nRelated Articles:")
    for i, article in enumerate(related_articles, 1):
        print(f"\nRelated Article {i}:")
        print(f"Title: {article['title']}")
        print(f"Link: {article['link']}")
        print(f"Introduction:\n{article['introduction']}")

if __name__ == '__main__':
    main()
