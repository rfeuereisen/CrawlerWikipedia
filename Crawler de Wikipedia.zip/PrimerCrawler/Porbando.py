import time
import urllib.request
import re
from bs4 import BeautifulSoup


def download_page(url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0;Win64) AppleWebkit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36'
        }
        req = urllib.request.Request(url, headers=headers)
        resp = urllib.request.urlopen(req)
        respData = str(resp.read())
        return respData
    except Exception as e:
        print(str(e))


def extract_title(page):
    start_title = page.find("<span dir")
    end_start_title = page.find(">", start_title + 1)
    stop_title = page.find("</span>", end_start_title + 1)
    title = page[end_start_title + 1:stop_title]
    return title


def extract_see_also(page):
    if 'id="See_also">' in page:
        start_see_also = page.find('id="See_also">')
        start_list_items = page.find('<li>', start_see_also + 1)
        end_see_also = page.find('<h2>', start_list_items + 1)
        see_also_section = page[start_list_items: end_see_also]
        pure_item_raw = (re.sub(r'<.+?>', '', see_also_section)).replace('\n', ',')
        pure_item_raw2 = pure_item_raw.replace(',,', ',')
        pure_item = pure_item_raw2.replace(',,', ',')
        flag = 0
    else:
        pure_item = "No Related Links"
        flag = 1
    return pure_item, flag


def extract_introduction(page):
    start_introduction = page.find("<p>")
    stop_introduction = page.find('<div id="toctitle">', start_introduction + 1)

    if '<div id="toctitle">' not in page:
        stop_introduction = page.find('</p>', start_introduction + 1)
    else:
        pass

    raw_introduction = page[start_introduction: stop_introduction]
    return raw_introduction


def extract_pure_introduction(page):
    pure_introduction = (re.sub(r'<.+?>', '', page))
    return pure_introduction


def extension_scan(url):
    extensions = ['.png', '.jpg', '.jpeg', '.gif', '.tif', '.txt']
    for ext in extensions:
        if ext in url:
            return True
    return False


def url_parse(url):
    try:
        from urllib.parse import urlparse
    except ImportError:
        from urlparse import urlparse
    url = url
    s = urlparse(url)
    seed_page_n = seed_page
    i = 0
    flag = 0
    while i <= 9:
        if url == "/":
            url = seed_page_n
            flag = 0
        elif not s.scheme:
            url = "http://" + url
            flag = 0
        elif "#" in url:
            url = url[:url.find("#")]
            flag = 0
        elif "?" in url:
            url = url[:url.find("?")]
            flag = 0
        elif s.netloc == "":
            url = seed_page + s.path
            flag = 0
        elif url[len(url) - 1] == "/":
            url = url[:-1]
            flag = 0
        else:
            url = url
            flag = 0
            break

        i = i + 1
        s = urlparse(url)
    return url, flag


def get_all_links(page):
    soup = BeautifulSoup(page, 'html.parser')
    links = [a['href'] for a in soup.find_all('a', href=True)]
    return links


def web_crawl(search_term, num_iterations):
    to_crawl = [starting_page]
    crawled = []
    database = {}
    for k in range(num_iterations):
        i = 0
        while i < num_iterations:
            url = to_crawl.pop(0)
            url, flag = url_parse(url)
            flag2 = extension_scan(url)
            time.sleep(3)

            if flag == 1 or flag2 == 1:
                pass
            else:
                if url in crawled:
                    pass
                else:
                    print("Link:", url)

                    raw_html = download_page(url)

                    title_upper = str(extract_title(raw_html))
                    title = title_upper.lower()
                    print("Title:", title)

                    see_also, flag2 = extract_see_also(raw_html)
                    print("Related Links:", see_also)

                    raw_introduction = extract_introduction(raw_html)
                    to_crawl = to_crawl + get_all_links(raw_introduction)
                    crawled.append(url)

                    pure_introduction = extract_pure_introduction(raw_introduction)
                    print("Introduction:", pure_introduction.replace('   ', ' '))

                    database[title] = pure_introduction

                    file = open('database.txt', 'a')
                    file.write(title + ":\n")
                    file.write(pure_introduction + "\n\n")
                    file.close()

                    n = 1
                    j = 0
                    while j < (len(to_crawl) - n):
                        if to_crawl[j] in to_crawl[j + 1:(len(to_crawl) - 1)]:
                            to_crawl.pop(j)
                            n = n + 1
                        else:
                            pass
                        j = j + 1
                i = i + 1
                print(i)
                print(k)
    return database


search_term = input("Enter the desired article: ")
num_iterations = int(input("Enter the number of iterations: "))

starting_page = "https://en.wikipedia.org/wiki/" + search_term.replace(' ', '_')
seed_page = "https://en.wikipedia.org"

t0 = time.time()
database = web_crawl(search_term, num_iterations)
t1 = time.time()

total_time = t1 - t0
print("Total Time:", total_time)

# Print the extracted information in a coherent format
for title, introduction in database.items():
    print("Title:", title)
    print("Introduction:", introduction)
    print()
